/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8_2;

/**
 *
 * @author Lenovo
 */
public class NumericQuestion extends Question{
    
    public NumericQuestion(String question){
        super(question);
    }
    @Override
    public boolean checkAnswer(String response){
        double result = Double.parseDouble(response) - Double.parseDouble(super.getAnswer());
        boolean correct = Math.abs(result) <= 0.01 ;
        return correct;
    }
}
