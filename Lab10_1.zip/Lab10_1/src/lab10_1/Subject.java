/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_1;

/**
 *
 * @author Lenovo
 */
public class Subject implements Evaluation {
    
    private String subjName;
    private int score[];
    
    public Subject(String subjName, int score[]){
        this.subjName = subjName;
        this.score = score;
    }
    @Override
    public double evaluate(){
        double point = 0;
        for(int i = 0; i<score.length; i++){
            point += score[i];
        }
        return point;
    }
    @Override
    public char grade(double point){
        point = evaluate();
        if(point>=70){
            return 'P';
        }
        else{
            return 'F';
        }
    }
    @Override
    public String toString(){
        return subjName;
    }
}
