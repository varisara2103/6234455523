/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_2;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Lenovo
 */
public class Game {
    private int comWin;
    private int userWin;
    private int com;
    
    public void play(){
        while (userWin-comWin != 2 && comWin-userWin != 2){
            Scanner in = new Scanner(System.in);
            System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS: ");
            String user = in.next();
            switch(user){
                case "0" : System.out.println("You enter: ROCK");break;
                case "1" : System.out.println("You enter: PAPER");break;
                case "2" : System.out.println("You enter: SCISSORS");break;
                default: continue;
            }
            Random comTurn = new Random();
            com = comTurn.nextInt(3);
            switch(com){
                case 0 : System.out.println("You enter: ROCK");break;
                case 1 : System.out.println("You enter: PAPER");break;
                case 2 : System.out.println("You enter: SCISSORS");break;
                default: continue;
            }
            if ("0".equals(user))switch(com){
                case 0 : System.out.println("It's a tie.");break;
                case 1 : System.out.println("You lose!");comWin++;break;
                case 2 : System.out.println("You win!");userWin++;break;
            }
            else if ("1".equals(user))switch(com){
                case 0 : System.out.println("You win!");userWin++;break;
                case 1 : System.out.println("It's a tie.");break;
                case 2 : System.out.println("You lose!");comWin++;break;
            }
            else switch(com){
                case 0 : System.out.println("You lose!");comWin++;break;
                case 1 : System.out.println("You win!");userWin++;break;
                case 2 : System.out.println("It's a tie.");break;
            } 
        }
        if (userWin>comWin){
            System.out.println("----------------------------------------");
            System.out.println("Congrats! You win.");
            System.out.println("User Score: "+userWin);
            System.out.println("Computer score: "+comWin);
        }
        else{
            System.out.println("----------------------------------------");
            System.out.println("Too bad! You lose.");
            System.out.println("User Score: "+userWin);
            System.out.println("Computer score: "+comWin);
        }
    }
       
}
