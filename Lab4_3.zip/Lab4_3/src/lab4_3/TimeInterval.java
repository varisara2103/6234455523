/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_3;

/**
 *
 * @author Lenovo
 */
public class TimeInterval {
    private int start;
    private int end;
    private double startminutes;
    private double endminutes;
    private double minutes;
    public TimeInterval(int start, int end){
        startminutes=((start/100)*60)+(start%100);
        endminutes=((end/100)*60)+(end%100);
        minutes=endminutes-startminutes;
        
    }
    public int getHours(){
        double hours = Math.floor(minutes)/60;
        return (int)hours;
    }
    public int getMinutes(){
        double min = minutes%60;
        return (int)min;
    }
    
    
}
