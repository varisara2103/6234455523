/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_1;

/**
 *
 * @author Lenovo
 */
public class Secretary extends Employee implements Evaluation {
    
    private int typingSpeed;
    private int score[];
    
    public Secretary(String name, int salary, int score[], int typingSpeed){
        super(name, salary);
        this.typingSpeed = typingSpeed;
        this.score = score;
    }
    @Override
    public double evaluate(){
        double point = 0;
        for(int i = 0; i<2; i++){
            point += score[i];
        }
        return point;
    }
    @Override
    public char grade(double point){
        point = evaluate();
        if(point>=90){
            super.setSalary(18000);
            return 'P';
        }
        else{
            return 'F';
        }
    }
}