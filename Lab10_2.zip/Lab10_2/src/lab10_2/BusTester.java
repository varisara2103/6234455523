/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_2;

import java.util.ArrayList;

/**
 *
 * @author Lenovo
 */
public class BusTester {
    public static void main(String[] args) {
        ArrayList<Bus> arr = new ArrayList<Bus>();
        Hybrid hybrid = new Hybrid(45,1.2E6,600,150,1);
        CNGBus cng = new CNGBus(50,1E6,200,2);
        arr.add(hybrid);
        arr.add(cng);
        
        for(int i=0; i<arr.size(); i++){
            if(arr.get(i) instanceof Hybrid){
                System.out.println("ID: "+ arr.get(i).getID() + "\nEmission Tier: "+ ((Hybrid)arr.get(i)).getEmissionTier()+"\nAccel: "+arr.get(i).getAccel());
            }
            if(arr.get(i) instanceof CNGBus){
                System.out.println("ID: "+ arr.get(i).getID() + "\nEmission Tier: "+ ((CNGBus)arr.get(i)).getEmissionTier()+"\nAccel: "+arr.get(i).getAccel());
            }
        }
    }
}
