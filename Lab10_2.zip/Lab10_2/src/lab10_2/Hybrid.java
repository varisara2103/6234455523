/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_2;

/**
 *
 * @author Lenovo
 */
public class Hybrid extends Bus implements LiquidFuel, Electric{
    
    double voltage;
    double range;
    int emissionTier;
    
    public Hybrid(int capacity, double cost, double voltage, double range, int emissionTier){
        super(capacity, cost);
        this.voltage = voltage;
        this.range = range;
        this.emissionTier = emissionTier;
        if(voltage<LOW_VOLTAGE){
            voltage = LOW_VOLTAGE;
        }
        if(voltage>HIGH_VOLTAGE){
            voltage = HIGH_VOLTAGE;
        }
    }
    @Override
    public double getRange(){
        return range;
    }
    @Override
    public int getEmissionTier(){
        return emissionTier;
    }
    @Override
    public double getVoltage(){
        return voltage;
    }
    @Override
    public double getAccel(){
        return 4.0;
    }
}
