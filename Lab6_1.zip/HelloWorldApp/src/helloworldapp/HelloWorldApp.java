/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helloworldapp;

/**
 *
 * @author Lenovo
 */
public class Rectangle1 
{
 public static void main(String[] args) 
 {
    System.out.println("Area = " + 4.5*2);
    System.out.println("Perimeter = " + (4.5*2+2*2));
 }
}