package com.example.guessanumber;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {
    Button btnGuess;
    EditText userInput;
    TextView hint;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        userInput = findViewById(R.id.userInput);
        hint = findViewById(R.id.textHint);
        btnGuess = findViewById(R.id.btn2);
        final int randomInt = getIntent().getExtras().getInt("randomInt");
        btnGuess.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                int userGuess = Integer.parseInt(userInput.getText().toString());
                if (userGuess > randomInt) {
                    hint.setText("Your guess is too high");
                    userInput.setText("");

                }
                else if (userGuess < randomInt) {
                    hint.setText("Your guess is too low");
                    userInput.setText("");
                }
                else{
                    Intent startIntent = new Intent(SecondActivity.this,ResultActivity.class);
                    startActivity(startIntent);
                }
            }
        });
    }
}
