/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_2;

import java.util.Scanner;

/**
 *
 * @author Lenovo
 */
public class MagicSquareTester {
    public static void main(String[] args){
        Scanner keyboard = new Scanner(System.in);
        int number;
        System.out.println("\tMagic square");
        do{
            System.out.print("Enter odd number to start program: ");
            number = keyboard.nextInt();
        }
        while(number%2 == 0);
        MagicSquare play = new MagicSquare();
        play.makeSquare(number);
        play.FillSquare();
        System.out.println(play.toString());
        
    }
}
