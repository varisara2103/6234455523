/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_1;

/**
 *
 * @author usci
 */
public class SodaCan {
    private double height;
    private double radius;
    public SodaCan(double height,double diameter){
        this.height = height;
        radius = diameter/2;
    }
    public double getVolume(){
        double volume = Math.PI*Math.pow(radius, 2)*height;
        return volume;
    }
    public double getSurfaceArea(){
        double surfaceArea = (2*Math.PI*Math.pow(radius, 2))+(2*Math.PI*radius*height);
        return surfaceArea;
    }
}
