package com.example.easterday;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    static String easterDay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final EditText editText = findViewById(R.id.editText);
        Button butt = findViewById(R.id.butt);
        butt.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String theYear = editText.getText().toString();
                if (theYear.length()!= 0){
                    int num = Integer.parseInt(theYear);
                    EasterSunday easter = new EasterSunday(num);
                    easterDay = easter.examine();
                    startActivity(new Intent(MainActivity.this, com.example.easterday.Result.class));

                }
            }

        });
    }
}



