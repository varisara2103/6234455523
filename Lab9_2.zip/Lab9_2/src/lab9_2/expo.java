/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9_2;

/**
 *
 * @author Lenovo
 */
public class expo extends Taylor {

    public expo(int k, double x) {
        super(k, x);
    }
    @Override
    public double getApprox(){
        double answer = 0;
        for(int i = 0; i<=super.getlter(); i++){
            answer += Math.pow(super.getValue(),i)/super.factorial(i);
        }
        return answer;
    }
    @Override
    public void printValue(){
        System.out.println("Value from Math.exp() is "+Math.exp(super.getValue()));
        System.out.println("Approximated value is "+getApprox());
    }
}
