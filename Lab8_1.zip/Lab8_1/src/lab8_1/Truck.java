/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8_1;

/**
 *
 * @author Lenovo
 */
public class Truck extends Car {
    
    private double weight;
    private double M_weight;
    private double use;
    
    public Truck(double gas, double efficiency,double weight,double M_weight ) {
        super(gas, efficiency);
        this.weight = weight;
        this.M_weight = M_weight;
        if(weight<M_weight){
            weight = M_weight;
        }
    }
    @Override
    public void drive(double distance){
        if(weight>20){
            use = (distance/super.getEfficiency())*1.3;
        }
        else if(weight>10){
            use = (distance/super.getEfficiency())*1.2;
        }
        else if (weight>1){
            use = (distance/super.getEfficiency())*1.1;
        }
        else {
            use = distance/super.getEfficiency();
        }
        if(use<super.getGas()){
            double gas = super.getGas()-use;
            super.setGas(gas);
        }
        else{
            System.out.println("You cannot drive too far, please add gas");
        }
    }
}
