/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab11_1;

import java.util.ArrayList;

/**
 *
 * @author Lenovo
 */
public class MusicBox implements SimpleQueue{
    
    private ArrayList<Object> song = new ArrayList<>();
    
    @Override
    public void enqueue(Object o){
        song.add(o);
        System.out.println(o+" is added in queue");
    }
    @Override
    public void dequeue(){
        System.out.println("Now playing "+song.get(0));
        song.remove(0);
    }
}
