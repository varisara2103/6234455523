/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_1;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author Lenovo
 */
public class Purse {
    ArrayList<String> wallet = new ArrayList<String>();
    public void coinType(String coin){
        wallet.add(coin);
    }
    public String toString(){
        String InWallet = String.join(",", wallet);
        System.out.println(InWallet);
        return InWallet;
    }
    public ArrayList<String> reverse(){
        Collections.reverse(wallet);
        System.out.println(wallet);
        return wallet;
    }
    public void transfer(ArrayList<String> coinB, ArrayList<String> coinA){
        int x = coinA.size();
        Collections.reverse(coinA);
        Collections.reverse(coinB);
        for(int i=0; i<x; i++){
            coinB.add(coinA.get(0));
            coinA.remove(0);
        }
        System.out.println("Transfer wallet: \n" +coinA+"\n"+coinB);
    }
    public boolean sameContents(ArrayList<String> coinB, ArrayList<String> coinA){
        int coin1=0;
        int x = coinA.size();
        int y = coinB.size();
        String a = coinA.toString();
        if(x==y){
            for(int i=0; i<x; i++){
                switch(coinA.get(i)){
                    case "Penny":
                        if("Penny".equals(coinB.get(i))){
                            coin1++;
                        }
                        break;
                    case "Nickle":
                        if("Nickle".equals(coinB.get(i))){
                            coin1++;
                        }
                        break;
                    case "Dime":
                        if("Dime".equals(coinB.get(i))){
                            coin1++;
                        }
                        break;
                    case "Half":
                        if("Half".equals(coinB.get(i))){
                            coin1++;
                        }
                        break;
                    case "Quarter":
                        if("Quarter".equals(coinB.get(i))){
                            coin1++;
                        }
                        break;
                }
            }
        }
        else{
            return false;
        }
        return coin1==x;
    }
    public boolean sameCoins(ArrayList<String> coinB, ArrayList<String> coinA){
        int x = coinA.size();
        int y = coinB.size();
        int coin1=0,coin2=0;
        if(x==y){
            for(int i=0;i<x;i++){
                switch(coinA.get(i)){
                    case "Penny":{coin1++;}
                    case "Nickel":{coin1++;}
                    case "Dime":{coin1++;}
                    case "Half":{coin1++;}
                    case "Quarter":{coin1++;}
                }switch(coinB.get(i)){
                    case "Penny":{coin2++;}
                    case "Nickel":{coin2++;}
                    case "Dime":{coin2++;}
                    case "Half":{coin2++;}
                    case "Quarter":{coin2++;}
                }
            }
            return coin1==coin2;
        }
        else{
            return false;
        }
    }
}
